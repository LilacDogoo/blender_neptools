# blender_neptools
<p>A set of Blender tools to Import and Export to the Neptunia Games

<p>I am hoping to make a decent set of tools for as many neptunia games as I can.

<p>Currently I have importing models working for:
<ul>
<li>Hyperdimension Neptunia Re;Birth1
<li>Hyperdimension Neptunia Re;Birth2
<li>Hyperdimension Neptunia Re;Birth3
<li>Megadimension Neptunia VII
</ul>

<p>Some face textures will fail. I assume it has to do with the way the faces are animated.

<p>I am quite familiar with Java but I am very new to Python.
<p>Blender add-ons are written in Python so I had to learn.
